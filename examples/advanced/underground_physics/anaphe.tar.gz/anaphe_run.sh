#!/bin/sh
unset LHCXX_REL_DIR
unset LHCXXVERS
unset PLATF
#export PATH=/usr/local/gcc-alt-2.95.2/bin:$PATH; 
#export LD_LIBRARY_PATH=/usr/local/gcc-alt-2.95.2/lib:$LD_LIBRARY_PATH
rm -rf lhcxx
mkdir lhcxx
unset LHCXXTOP
unset PLATF
#./anaphe-setup.py --topDir `pwd`/lhcxx --version 4.0.1-sec
./anaphe-setup.py --topDir `pwd`/lhcxx --version 4.0.3
#./anaphe-setup.py --topDir `pwd`/lhcxx --version 3.6.6

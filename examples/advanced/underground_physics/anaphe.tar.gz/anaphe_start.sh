export AIDA_DIR = `pwd`
export LHCXXTOP=`pwd`/lhcxx
source $LHCXXTOP/share/LHCXX/4.0.3-sec/install/sharedstart.sh
export PATH=$PATH:$LHCXXTOP/specific/redhat61/egcs_1.1.2/4.0.3-sec/bin

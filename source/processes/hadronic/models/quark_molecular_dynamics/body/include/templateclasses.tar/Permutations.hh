#ifndef __PERMUT__
#define __PERMUT__

#include <vector>

template<class t>
G4std::vector<t>& operator>>(G4std::vector<t>& v,int n); 

template<class t>
G4std::vector<t> operator>>(const G4std::vector<t>& v,int n);

template<class t>
G4std::vector<t> swap(const G4std::vector<t>& w,int i,int j);

template<class t>
G4std::vector< G4std::vector<t> > Permutations(const G4std::vector<t>& start);

template<class t>
bool compare(const G4std::vector<t>&,const G4std::vector<t>&);

#ifndef IS_GCC
#include "Permutations.tcc"
#endif

#endif
      
// This code implementation is the intellectual property of
// the GEANT4 collaboration.
//
// By copying, distributing or modifying the Program (or any work
// based on the Program) you indicate your acceptance of this statement,
// and all its terms.
//
// $Id: TestLowEn.tar,v 1.4 1999-12-15 14:51:35 gunter Exp $
// GEANT4 tag $Name: not supported by cvs2svn $
//
// 
// --------------------------------------------------------------
//      GEANT 4 - TestLowEn 
//
//      For information related to this code contact:
//      CERN, IT Division, ASD Group
// --------------------------------------------------------------
// Comments
//     
//   
// --------------------------------------------------------------

#include "G4RunManager.hh"
#include "G4UImanager.hh"
#include "G4UIterminal.hh"
#include "Randomize.hh"

#include "LowEnDetectorConstruction.hh"
#include "LowEnPhysicsList.hh"
#include "LowEnPrimaryGeneratorAction.hh"
#include "LowEnRunAction.hh"
#include "LowEnEventAction.hh"
#include "LowEnSteppingAction.hh"

#ifdef GNU_GCC
#include "g4rw/tpordvec.h"
#include "LowEnCalorHit.hh"
template class G4RWTPtrOrderedVector <LowEnCalorHit>;
template class G4RWTPtrVector <LowEnCalorHit>;
template class G4Allocator <LowEnCalorHit>;
#endif

int main(int argc,char** argv) {

  //choose the Random engine
  HepRandom::setTheEngine(new RanecuEngine);
  
  // Construct the default run manager
  G4RunManager * runManager = new G4RunManager;

  // set mandatory initialization classes
  LowEnDetectorConstruction* detector;
  detector = new LowEnDetectorConstruction;
  runManager->SetUserInitialization(detector);
  runManager->SetUserInitialization(new LowEnPhysicsList(detector));
  
  // set user action classes
  runManager->SetUserAction(new LowEnPrimaryGeneratorAction(detector));
  LowEnRunAction* runaction = new LowEnRunAction;
  runManager->SetUserAction(runaction);

  LowEnEventAction* eventaction = new LowEnEventAction(runaction);
  runManager->SetUserAction(eventaction);

  LowEnSteppingAction* steppingaction = new LowEnSteppingAction(detector,
                                               eventaction, runaction);
  runManager->SetUserAction(steppingaction);
    
  // get the pointer to the User Interface manager 
    G4UImanager* UI = G4UImanager::GetUIpointer();  
 
  if (argc==1)   // Define UI terminal for interactive mode  
    { 
     G4UIsession * session = new G4UIterminal;
     UI->ApplyCommand("/control/execute init.mac");    
     session->SessionStart();
     delete session;
    }
  else           // Batch mode
    { 
     G4String command = "/control/execute ";
     G4String fileName = argv[1];
     UI->ApplyCommand(command+fileName);
    }
  // job termination
  delete r